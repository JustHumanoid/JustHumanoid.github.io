function show(LIFE, PAUSE)
    %  Initialize
    if nargin == 1;
        PAUSE = .03;
    end
    
    % Visualize
    name = 'Conway''s Game of Life';
    button.quit = uicontrol('style','tog','str','quit','pos',[180 20 60 20]);
    t = 1;
    snapshots = size(LIFE,2);
    while t <= snapshots
        % stop if quit is pressed
        if (get(button.quit,'val') == 1)
            break
        end
        % Use spy to plot.  Title shows name and time.
        spy(LIFE{t})
        title(sprintf('%s %4d',name,t))
        pause(PAUSE)
        t = t+1;
    end
    % wait until quit is pressed
    while (get(button.quit,'val') == 0)
        pause(PAUSE)
    end
    close(gcf)
end