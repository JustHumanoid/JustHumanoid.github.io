%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%     Programmeervaardigheden : Opdracht 2      %%
%%           Academiejaar 2012 - 2013            %%
%% Conway's Game of Life : Pulsar / Puffer Train %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% geef aan hoeveel tijdstappen je wilt uitvoeren
TIME = 10;

% het beginuniversum is gecodeerd in een apart bestand. De keuze bestaat
% uit pulsar.m (een klein universum) en puffer_train.m (een erg groot, dus 
% traag te berekenen universum). Beide maken een matrix genaamd 'X' aan.
pulsar;
%puffer_train;

% initialiseer de eerste tijdstap van de 'life' array met het
% beginuniversum. Je kan op dezelfde manier een nieuwe tijdstap toevoegen 
% aan je 'life' array als bij een matrix, maar de index wordt tussen 
% accolades in plaats van haakjes gegeven.
life{1} = X;

%%%%%%%%%%%%%%%%%%%%%%%%
% schrijf je code hier %
%%%%%%%%%%%%%%%%%%%%%%%%




% de twee laatste lijnen moeten onderaan dit bestand blijven
% ze starten een programma op dat jouw game of life visualiseert
%    je kan de simulatie trager of sneller laten lopen door de DELAY parameter mee te geven (standaardwaarde 0.03 seconden)
%       bijvoorbeeld: show(life, 0.1)
show(life);
